const API = 'http://localhost:5000/api';
let token = localStorage.getItem('token');
let cart = JSON.parse(localStorage.getItem('cart') || '[]');

function updateUI() {
  if (token) {
    document.getElementById('auth-area').style.display = 'none';
    document.getElementById('user-area').style.display = 'block';
    document.getElementById('welcome').textContent = 'Welcome!';
  } else {
    document.getElementById('auth-area').style.display = 'block';
    document.getElementById('user-area').style.display = 'none';
  }
  document.getElementById('cart-count').textContent = cart.reduce((s, i) => s + i.qtyKg, 0);
}

async function loadProducts() {
  const res = await fetch(`${API}/products`);
  const products = await res.json();
  const container = document.getElementById('products');
  container.innerHTML = products.map(p => `
    <div class="product-card">
      <h3>${p.name}</h3>
      <p>${p.category} • Min ${p.minOrderQty} kg</p>
      <p class="price">₹${p.pricePerKg}/kg</p>
      <p>Stock: ${p.stockKg} kg</p>
      <input type="number" id="qty-${p._id}" value="${p.minOrderQty}" min="${p.minOrderQty}" style="width:80px; display:inline-block;" />
      <button onclick="addToCart('${p._id}', '${p.name}', ${p.pricePerKg}, ${p.minOrderQty})">Add</button>
    </div>
  `).join('');
}

function addToCart(id, name, price, minQty) {
  if (!token) return alert('Please login first');
  const qty = parseFloat(document.getElementById(`qty-${id}`).value);
  if (qty < minQty) return alert(`Minimum order is ${minQty} kg`);
  const existing = cart.find(i => i.productId === id);
  if (existing) existing.qtyKg += qty;
  else cart.push({ productId: id, name, pricePerKg: price, qtyKg: qty });
  localStorage.setItem('cart', JSON.stringify(cart));
  updateUI();
  alert('Added to cart');
}

function showCart() {
  document.getElementById('products-section').style.display = 'none';
  document.getElementById('cart-section').style.display = 'block';
  const container = document.getElementById('cart-items');
  let total = 0;
  container.innerHTML = cart.map(i => {
    const sub = i.qtyKg * i.pricePerKg;
    total += sub;
    return `<div style="display:flex; justify-content:space-between; margin:8px 0;">
      <span>${i.name} – ${i.qtyKg} kg × ₹${i.pricePerKg}</span>
      <strong>₹${sub}</strong>
    </div>`;
  }).join('') || '<p>Cart is empty</p>';
  document.getElementById('cart-total').textContent = total;
}

function hideCart() {
  document.getElementById('cart-section').style.display = 'none';
  document.getElementById('products-section').style.display = 'block';
}

async function placeOrder() {
  const address = document.getElementById('address').value;
  if (!address) return alert('Enter delivery address');
  if (!cart.length) return alert('Cart is empty');

  const res = await fetch(`${API}/orders`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
    body: JSON.stringify({ items: cart, deliveryAddress: address })
  });
  const data = await res.json();
  if (res.ok) {
    alert('Order placed successfully!');
    cart = [];
    localStorage.setItem('cart', '[]');
    updateUI();
    hideCart();
    loadProducts();
  } else {
    alert(data.error || 'Order failed');
  }
}

function showLogin() {
  document.getElementById('auth-forms').style.display = 'block';
  document.getElementById('login-form').style.display = 'block';
  document.getElementById('register-form').style.display = 'none';
}
function showRegister() {
  document.getElementById('auth-forms').style.display = 'block';
  document.getElementById('login-form').style.display = 'none';
  document.getElementById('register-form').style.display = 'block';
}

async function register() {
  const username = document.getElementById('reg-username').value;
  const mobile = document.getElementById('reg-mobile').value;
  const password = document.getElementById('reg-pass').value;
  const res = await fetch(`${API}/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, mobile, password })
  });
  const data = await res.json();
  if (res.ok) {
    token = data.token;
    localStorage.setItem('token', token);
    updateUI();
    document.getElementById('auth-forms').style.display = 'none';
    alert('Registered successfully!');
  } else alert(data.error);
}

async function login() {
  const usernameOrMobile = document.getElementById('login-user').value;
  const password = document.getElementById('login-pass').value;
  const res = await fetch(`${API}/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ usernameOrMobile, password })
  });
  const data = await res.json();
  if (res.ok) {
    token = data.token;
    localStorage.setItem('token', token);
    updateUI();
    document.getElementById('auth-forms').style.display = 'none';
  } else alert(data.error);
}

function logout() {
  token = null;
  localStorage.removeItem('token');
  updateUI();
}

// Init
updateUI();
loadProducts();