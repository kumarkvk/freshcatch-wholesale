require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const User = require('./models/User');
const Product = require('./models/Product');
const Order = require('./models/Order');

const app = express();
app.use(cors());
app.use(express.json());

const path = require('path');

// Serve the frontend static files
app.use(express.static(path.join(__dirname, 'frontend')));

// Fallback for SPA-style routing (optional)
app.get('*', (req, res) => {
  if (!req.path.startsWith('/api')) {
    res.sendFile(path.join(__dirname, 'frontend', 'index.html'));
  }
});

mongoose.connect(process.env.MONGO_URI || 'mongodb://fishuser:FishPass123!@mongodb.mongodb.svc.cluster.local:27017/wholesale_fish')

// Connect DB
mongoose.connect(process.env.MONGO_URI || 'mongodb://fishuser:FishPass123!@mongodb.mongodb.svc.cluster.local:27017/wholesale_fish')
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error(err));

// Auth middleware
const auth = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'No token' });
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET || 'secret');
    next();
  } catch {
    res.status(401).json({ error: 'Invalid token' });
  }
};

// ===== AUTH =====
app.post('/api/register', async (req, res) => {
  try {
    const { username, mobile, password } = req.body;
    if (!username || !mobile || !password) {
      return res.status(400).json({ error: 'All fields required' });
    }
    const exists = await User.findOne({ $or: [{ username }, { mobile }] });
    if (exists) return res.status(400).json({ error: 'Username or mobile already exists' });

    const hashed = await bcrypt.hash(password, 10);
    const user = await User.create({ username, mobile, password: hashed });
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET || 'secret', { expiresIn: '7d' });
    res.json({ token, user: { id: user._id, username, mobile } });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/login', async (req, res) => {
  try {
    const { usernameOrMobile, password } = req.body;
    const user = await User.findOne({
      $or: [{ username: usernameOrMobile }, { mobile: usernameOrMobile }]
    });
    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET || 'secret', { expiresIn: '7d' });
    res.json({ token, user: { id: user._id, username: user.username, mobile: user.mobile } });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ===== PRODUCTS =====
app.get('/api/products', async (req, res) => {
  const products = await Product.find({ isActive: true }).sort({ name: 1 });
  res.json(products);
});

// Seed sample products (run once)
app.post('/api/seed', async (req, res) => {
  await Product.deleteMany({});
  const sample = [
    { name: 'Rohu', category: 'Freshwater', pricePerKg: 180, minOrderQty: 10, stockKg: 800, description: 'Fresh Rohu fish' },
    { name: 'Katla', category: 'Freshwater', pricePerKg: 200, minOrderQty: 10, stockKg: 600, description: 'Premium Katla' },
    { name: 'Hilsa', category: 'Marine', pricePerKg: 850, minOrderQty: 5, stockKg: 200, description: 'Bangla Hilsa' },
    { name: 'Pomfret', category: 'Marine', pricePerKg: 650, minOrderQty: 5, stockKg: 150, description: 'White Pomfret' },
    { name: 'Seer Fish', category: 'Marine', pricePerKg: 720, minOrderQty: 5, stockKg: 120, description: 'Surmai / Seer' }
  ];
  await Product.insertMany(sample);
  res.json({ message: 'Sample products added' });
});

// ===== ORDERS =====
app.post('/api/orders', auth, async (req, res) => {
  try {
    const { items, deliveryAddress } = req.body;
    if (!items || !items.length) return res.status(400).json({ error: 'Cart is empty' });

    let totalAmount = 0;
    const orderItems = [];

    for (const item of items) {
      const product = await Product.findById(item.productId);
      if (!product) return res.status(400).json({ error: `Product not found` });
      if (item.qtyKg < product.minOrderQty) {
        return res.status(400).json({ error: `${product.name} minimum order is ${product.minOrderQty} kg` });
      }
      if (item.qtyKg > product.stockKg) {
        return res.status(400).json({ error: `Not enough stock for ${product.name}` });
      }
      totalAmount += item.qtyKg * product.pricePerKg;
      orderItems.push({
        product: product._id,
        name: product.name,
        qtyKg: item.qtyKg,
        pricePerKg: product.pricePerKg
      });
      // reduce stock
      product.stockKg -= item.qtyKg;
      await product.save();
    }

    const order = await Order.create({
      user: req.user.id,
      items: orderItems,
      totalAmount,
      deliveryAddress
    });

    res.json({ message: 'Order placed successfully', order });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/my-orders', auth, async (req, res) => {
  const orders = await Order.find({ user: req.user.id }).sort({ createdAt: -1 });
  res.json(orders);
});

##//const PORT = process.env.PORT || 5000;
##//app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));

const PORT = process.env.PORT || 5000;
app.listen(PORT, '0.0.0.0', () => console.log(`Server running on port ${PORT}`));