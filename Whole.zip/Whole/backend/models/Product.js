const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  name: { type: String, required: true },
  category: { type: String, default: 'Freshwater' },
  pricePerKg: { type: Number, required: true },
  minOrderQty: { type: Number, default: 5 },
  stockKg: { type: Number, default: 0 },
  image: { type: String, default: '' },
  description: String,
  isActive: { type: Boolean, default: true }
});

module.exports = mongoose.model('Product', productSchema);